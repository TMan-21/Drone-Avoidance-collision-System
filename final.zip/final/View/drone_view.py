import cv2

class DroneView:
    @staticmethod
    def display_frame(frame):
        """Display the video frame from the drone."""
        cv2.imshow("Tello Camera", frame)
        return cv2.waitKey(1) & 0xFF == ord('q')  # Quit on 'q' press
