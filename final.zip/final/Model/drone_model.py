import cv2
from djitellopy import Tello
import time

class DroneModel:
    def __init__(self):
        """Initialize Tello drone."""
        self.drone = Tello()
        if not self.drone.connect():
            print("Failed to connect to drone.")
            exit(1)
        self.drone.streamon()

    def takeoff(self):
        """Command the drone to take off."""
        self.drone.takeoff()
        time.sleep(2)
    
    def land(self):
        """Command the drone to land and stop video stream."""
        self.drone.land()
        self.drone.streamoff()
        cv2.destroyAllWindows()

    def move(self, direction):
        """Move the drone in the specified direction."""
        movements = {
            "left": self.drone.move_left,
            "right": self.drone.move_right,
            "front": self.drone.move_back,
            "forward": self.drone.move_forward
        }
        if direction in movements:
            movements[direction](20)

    def get_frame(self):
        """Retrieve the current video frame from the drone."""
        return self.drone.get_frame_read().frame

    def detect_obstacle(self, frame):
        """Detect obstacle direction based on image processing."""
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        edges = cv2.Canny(gray, 50, 150)
        height, width = edges.shape
        
        # Split frame into regions
        left_region = edges[:, :width // 3]
        center_region = edges[:, width // 3: 2 * width // 3]
        right_region = edges[:, 2 * width // 3:]
        
        # Count edges in each region
        left_edge_count = cv2.countNonZero(left_region)
        center_edge_count = cv2.countNonZero(center_region)
        right_edge_count = cv2.countNonZero(right_region)
        total_edges = left_edge_count + center_edge_count + right_edge_count

        # Determine obstacle location
        if total_edges > 3000:
            if center_edge_count > left_edge_count and center_edge_count > right_edge_count:
                return "front"
            elif left_edge_count > right_edge_count:
                return "left"
            else:
                return "right"
        return None