import time
from model.drone_model import DroneModel
from view.drone_view import DroneView

class DroneController:
    def __init__(self):
        """Initialize the controller with a drone model and view."""
        self.drone = DroneModel()
        self.view = DroneView()

    def run(self):
        """Main function to control the drone."""
        self.drone.takeoff()
        
        try:
            while True:
                frame = self.drone.get_frame()
                if frame is None:
                    print("No frame received.")
                    continue

                direction = self.drone.detect_obstacle(frame)

                if direction:
                    print(f"Obstacle detected {direction}! Moving accordingly.")
                    self.drone.move(direction)
                else:
                    print("No obstacle detected, moving forward.")
                    self.drone.move("forward")

                time.sleep(2)  # Allow time for movement

                if self.view.display_frame(frame):
                    break

        except Exception as e:
            print(f"Error: {e}")
        
        finally:
            self.drone.land()

if __name__ == "__main__":
    controller = DroneController()
    controller.run()
